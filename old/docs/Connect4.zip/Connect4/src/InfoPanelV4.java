import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class InfoPanelV4 extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = -9087485382471754307L;

	private JLabel diffInfoLabel;
	private JLabel diffLabel;
	private JLabel turnCountLabel;
	private JLabel turnLabel;
	private JLabel gameTypeLabel;
	private JLabel gameType;	
	private JLabel currPlayerLabel;
	private JLabel currPlayer; 
	private JLabel miscInfoLabel;
	
	private String currDiff;
	
	private Game game;
	
	/**
	 * Creates a new information panel with the specified game as the source of information.
	 * @param g
	 * The game to draw information from.
	 */
	public InfoPanelV4(Game g) {
		
		game = g;
		
		currDiff = game.getDiff();
		
		diffInfoLabel = new JLabel("Current Difficulty:");
		diffInfoLabel.setVisible(true);
		
		diffLabel = new JLabel(currDiff);
		
		turnCountLabel = new JLabel("Turn number:");
		turnCountLabel.setVisible(true);
		
		turnLabel = new JLabel(Integer.toString(game.getTurnCount()));
		
		gameTypeLabel = new JLabel ("Game Type: ");
		gameTypeLabel.setVisible(true);
		
		gameType = new JLabel(game.getGameType());
		gameTypeLabel.setVisible(true);
		
		currPlayerLabel = new JLabel("Player to move:");
		currPlayerLabel.setVisible(true);
		
		currPlayer = new JLabel(game.getCurrentPlayer());
		
		miscInfoLabel = new JLabel("");
		miscInfoLabel.setVisible(true);
		
		this.setLayout(new GridLayout(20,1));
		this.add(diffInfoLabel);
		this.add(diffLabel);
		this.add(turnCountLabel);
		this.add(turnLabel);
		this.add(gameTypeLabel);
		this.add(gameType);
		this.add(currPlayerLabel);
		this.add(currPlayer);
		this.add(miscInfoLabel);
		this.setVisible(true);
	}

	/**
	 * Sets a message in the miscellaneous message box.
	 * @param msg
	 * The message to write in the miscellaneous message box.
	 */
	public void setMiscMessage(String msg) {
		miscInfoLabel.setText(msg);
	}
	
	/**
	 * Checks the game for any and all data that is displayed on the information panel
	 * and updates the corresponding labels.
	 */
	public void refreshGameData() {
		turnLabel.setText(Integer.toString(game.getTurnCount()));
		diffLabel.setText(game.getDiff());
		currPlayer.setText(game.getCurrentPlayer());
		gameType.setText(game.getGameType());
	}
}
