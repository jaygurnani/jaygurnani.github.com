
/**
 * The Board class represents the Connect4 board.
 * Each board is 7 columns by 6 rows. They are numbered so that the leftmost column is column 0, and the topmost row is row 0.
 * Therefore, tile (0,0) is situated at the top left corner.
 */

public class Board {
	
	final protected int ROW = 6;
	final protected int COLUMN = 7;
	final protected int BLANK = 0;
	final protected int DRAW = 3;
	
	private Tile[][] board;
	private int isWon;
		
	/**
	 * Class constructor.
	 */
	public Board() {
		board = new Tile[6][7];		// Initialises the board with 6 rows and 7 columns
		for(int i=0; i<ROW; i++){	// Initially sets all the tiles to BLANK
			for(int j=0; j<COLUMN; j++){
				board[i][j] = new Tile(BLANK);
			}
		}
		isWon = Game.NO_DRAW;
	}
	
	
	/**
	 * Checks if column is free
	 * @param column
	 * Column to be checked if its free
	 * @return returns true if free
	 */
	
	public boolean isFree(int column){
		if(this.board[0][column].getData() == 0){
			return true;
		} else {
			return false; 
		}
	}

	/**
	 * Adds a piece to the board.
	 * @param player
	 * The player who is dropping the piece - Player One or Player Two.
	 * @param col
	 * The column in which the piece is being dropped.
	 * @return
	 * The row number in which it was dropped if the piece is successfully added, and -1 if there was no available space to add it.
	 */
	public int addPiece(int player, int col) {
		int i=5;
		if(col < COLUMN && col >= 0){					// If 'col' is within the bounds
			while(i >= 0 && i < ROW){					// Find the row with the next blank tile
				if(board[i][col].getData()==BLANK){
					if(player == Game.PLAYER_ONE){		// Changes the tile to the player's colour
						board[i][col].modifyTile(Game.PLAYER_ONE);
					}
					if(player == Game.PLAYER_TWO){
						board[i][col].modifyTile(Game.PLAYER_TWO);
					}
					isWon = hasWon(player, i, col);		// Updates if the last piece played is a winning piece
//					System.out.println(isWon);
					return i;
				}
				i--;
			}
		}
		return -1;
	}
	
	
	/**
	 * Calculates the total heuristic value using the individual heuristic values for both players
	 * @param g
	 * The board state for which we are calculating
	 * @return
	 * The total heuristic cost
	 */
	public int calculateHeuristic(Board g) {
		int totalCost = calculateHeuristicYellow(g) - 3*calculateHeuristicRed(g);
//		System.out.println("RED " + calculateHeuristicRed(g) + "YELLOW " + calculateHeuristicYellow(g));
		return totalCost;
	}
	
	
	/**
	 * Calculates the heuristic value for the yellow player
	 * @param g
	 * The board state for which we are calculating
	 * @return
	 * The heuristic cost
	 */
	public int calculateHeuristicYellow(Board g) {
		int cost = 0;
		for(int i=0; i<ROW; i++){														// For every tile on the board
			for(int j=0; j<COLUMN; j++){
				if(g.getTileType(i,j)==Game.PLAYER_TWO){
					int temp = checkVertical(i, j, Game.PLAYER_TWO, g.get2dArray());	// Check how many yellow pieces are
					cost = returnCost(cost, temp);										// adjacent to that tile, and update
					temp = checkHorizontal(i, j, Game.PLAYER_TWO, g.get2dArray());		// the cost according to that number
					cost = returnCost(cost, temp);
					temp = checkLeftDiagonal(i, j, Game.PLAYER_TWO, g.get2dArray());
					cost = returnCost(cost, temp);
					temp = checkRightDiagonal(i, j, Game.PLAYER_TWO, g.get2dArray());
					cost = returnCost(cost,temp);
				}
			}
		}
//		System.out.println("cost equals "+cost);
		return cost;
	}
	

	/**
	 * Calculates the heuristic value for the red player
	 * @param g
	 * The board state for which we are calculating
	 * @return
	 * The heuristic cost
	 */
	public int calculateHeuristicRed(Board g) {
		int cost = 0;
		for(int i=0; i<ROW; i++){														// For every tile on the board
			for(int j=0; j<COLUMN; j++){
				if(g.getTileType(i,j)==Game.PLAYER_ONE){
					int temp = checkVertical(i, j, Game.PLAYER_ONE, g.get2dArray());	// Check how many red pieces are
					cost = returnCost(cost, temp);										// adjacent to that tile, and update
					temp = checkHorizontal(i, j, Game.PLAYER_ONE, g.get2dArray());		// the cost according to that number
					cost = returnCost(cost, temp);
					temp = checkLeftDiagonal(i, j, Game.PLAYER_ONE, g.get2dArray());
					cost = returnCost(cost, temp);
					temp = checkRightDiagonal(i, j, Game.PLAYER_ONE, g.get2dArray());
					cost = returnCost(cost,temp);
				}
			}
		}
//		System.out.println("cost equals"+cost);
		return cost;
	}
	
	
	/**
	 * Updates the heuristic cost depending on how many same-coloured pieces are adjacent to the current tile.
	 * @param cost
	 * The current heuristic cost
	 * @param temp
	 * The number of adjacent same-coloured pieces
	 * @return
	 * The updated cost
	 */
	public int returnCost(int cost, int temp) {
		if(temp == 1){				// If there are no adjacent tiles
			cost = cost+temp;		// 1 is added to the cost
		}
		else if(temp == 2){			// If there are 2 adjacent tiles
			cost = cost+(temp*2);	// 2x2 is added to the cost
		}
		else if(temp == 3){			// If there are 3 adjacent tiles
			cost = cost+(temp*9);	// 3x9 is added to the cost
		}
		return cost;
	}
	
	
	/**
	 * Checks if the given player has won with the given piece
	 * @param player
	 * Player One or Two
	 * @param row
	 * The row of the given piece
	 * @param col
	 * The column of the given piece
	 * @return
	 * PLAYER_ONE_WINS (1) if Player One has won, PLAYER_TWO_WINS (2) if Player Two has won, 
	 * NO_DRAW (0) if nobody has won yet, and DRAW (3) if the game is a draw and the board is full.
	 */
	public int hasWon(int player, int row, int col){
		if(board[row][col].getData()!= BLANK){
			if(player == Game.PLAYER_ONE){									// For both players,
				if(checkVertical(row, col, Game.PLAYER_ONE, board)==4){		// Checks if there are any 4-in-a-rows
					return Game.PLAYER_ONE_WINS;							// connected to the given piece
				}
				if(checkHorizontal(row, col, Game.PLAYER_ONE, board)==4) {
					return Game.PLAYER_ONE_WINS;
				}
				if(checkLeftDiagonal(row, col, Game.PLAYER_ONE, board)==4){
					return Game.PLAYER_ONE_WINS;
				}
				if(checkRightDiagonal(row, col, Game.PLAYER_ONE, board)==4){
					return Game.PLAYER_ONE_WINS;
				}
			} else if (player == Game.PLAYER_TWO) {
				if(checkVertical(row, col, Game.PLAYER_TWO, board)==4){
					return Game.PLAYER_TWO_WINS;				}
				if(checkHorizontal(row, col, Game.PLAYER_TWO, board)==4) {
					return Game.PLAYER_TWO_WINS;
				}
				if(checkLeftDiagonal(row, col, Game.PLAYER_TWO, board)==4){
					return Game.PLAYER_TWO_WINS;
				}
				if(checkRightDiagonal(row, col, Game.PLAYER_TWO, board)==4){
					return Game.PLAYER_TWO_WINS;
				}
			}
		}

		if(draw()==true){		// If the given piece was not a winning piece and the board is now full,
			return Game.DRAW;	// return a Draw.
		}

		return Game.NO_DRAW;
	}
	
	/**
	 * Checks if the Red player has won
	 * @return
	 * True if Red has won, and false if not
	 */
	public boolean hasWonRed() {
		for(int i=0; i<ROW; i++){
			for(int j=0; j<COLUMN; j++){
				if (this.hasWon(Game.PLAYER_ONE, i, j) == Game.PLAYER_ONE_WINS){
					return true;
				}
			}
		}
		return false;
	}
	
	
	/**
	 * Checks if the Yellow player has won
	 * @return
	 * True if Yellow has won, and false if not
	 */
	public boolean hasWonYellow() {
		int i = 0;
		int j = 0;
		for(i=0; i<ROW; i++){
			for(j=0; j<COLUMN; j++){
				if (this.hasWon(Game.PLAYER_TWO, i, j) == Game.PLAYER_TWO_WINS){
					return true;
				}
			}
		}
		return false;
	}
	
	
	/**
	 * Checks if every tile on the board is occupied, and returns whether or not it is a draw.
	 * @return
	 * True if the game is a draw, false if it is not.
	 */
	public boolean draw() {
		for(int i=ROW-1; i>=0; i--){
			for(int j=0; j<COLUMN; j++){
				if(board[i][j].getData() == BLANK){
					return false;
				}
			}
		}
		return true;
	}
	
	
	/**
	 * Checks how many adjacent pieces in a row there are for the given tile diagonally
	 * The right diagonal is at 45 degrees
	 * @param rowInput
	 * The row of the given tile
	 * @param colInput
	 * The column of the given tile
	 * @param player
	 * The player to which the tile belongs to
	 * @param temp
	 * The board
	 * @return
	 * How many pieces in a row
	 */
	public int checkRightDiagonal(int rowInput, int colInput, int player, Tile[][] temp){
		int counter = 1;	// 1 is including itself
		int i=rowInput-1;
		int j=colInput+1;
		while(i>=0 && j<COLUMN && i>=rowInput-3 && j<=colInput+3 && temp[i][j].getData()==player){
			counter++;
			i--;
			j++;
		}
		i=rowInput+1;
		j=colInput-1;
		while(i<ROW && j>=0 && i<=rowInput+3 && j>=colInput-3 && temp[i][j].getData()==player){
			counter++;
			i++;
			j--;
		}
		return counter;
	}
	
	
	/**
	 * Checks how many adjacent pieces in a row there are for the given tile diagonally
	 * The left diagonal is at -45 degrees
	 * @param rowInput
	 * The row of the given tile
	 * @param colInput
	 * The column of the given tile
	 * @param player
	 * The player to which the tile belongs to
	 * @param temp
	 * The board
	 * @return
	 * How many pieces in a row
	 */
	public int checkLeftDiagonal(int rowInput, int colInput, int player, Tile[][] temp){
		int counter = 1;	// 1 is including itself
		int i=rowInput+1;
		int j=colInput+1;
		while(i<ROW && j<COLUMN && i<=rowInput+3 && j<=colInput+3 && temp[i][j].getData()==player){
			counter++;
			i++;
			j++;
		}
		i=rowInput-1;
		j=colInput-1;
		while(i>=0 && j>=0 && i>=rowInput-3 && j>=colInput-3 && temp[i][j].getData()==player){
			counter++;
			i--;
			j--;
		}
		return counter;
	}
	
	
	/**
	 * Checks how many adjacent pieces in a row there are for the given tile horizontally
	 * @param rowInput
	 * The row of the given tile
	 * @param colInput
	 * The column of the given tile
	 * @param player
	 * The player to which the tile belongs to
	 * @param temp
	 * The board
	 * @return
	 * How many pieces in a row
	 */
	public int checkHorizontal(int rowInput, int colInput, int player, Tile[][] temp){
		int counter=1;
		int j=0;
		for(j=colInput+1; j<COLUMN && j<=colInput+3 && temp[rowInput][j].getData()==player; j++){
			counter++;
		}
		for(j=colInput-1; ((j>=0 && j>=colInput-3) && temp[rowInput][j].getData()==player); j--){
			counter++;
		}
		return counter;
	}
	
	
	/**
	 * Checks how many adjacent pieces in a row there are for the given tile vertically
	 * @param rowInput
	 * The row of the given tile
	 * @param colInput
	 * The column of the given tile
	 * @param player
	 * The player to which the tile belongs to
	 * @param temp
	 * The board
	 * @return
	 * How many pieces in a row
	 */
	public int checkVertical(int rowInput, int colInput, int player, Tile[][] temp){
		int counter=1;
		int i=0;
		for(i=rowInput+1; ((i<ROW && i<=rowInput+3) && temp[i][colInput].getData()==player); i++){
			counter++;
		}
		for(i=rowInput-1; (i<ROW && i>=0 && i>=rowInput-3 && temp[i][colInput].getData()==player); i--){
			counter++;
		}
		return counter;
	}
	
	
	/**
	 * Finds the next empty tile in a column
	 * @param col
	 * The given column
	 * @return
	 * The next empty row, or -1 if the column is full
	 */
	public int getNextEmpty(int col) {
		int result = -1; // false
		
		for (int i = ROW - 1; i >= 0 && result == -1; i--) {
			if (board[i][col].getData() == BLANK) {
				result = i;
			}
		}
		return result;
	}
	

	/**
	 * Returns the type of the given tile
	 * @param i
	 * The row of the tile
	 * @param j
	 * The column of the tile
	 * @return
	 * Red, yellow or blank
	 */
	public int getTileType(int i, int j) {	
		return board[i][j].getData();
	}
	
	
	/**
	 * Resets the entire board to blank
	 */
	public void clear() {
		for (int i = 0; i < ROW; i++) {
			for (int j = 0; j < COLUMN; j++) {
				board[i][j].modifyTile(BLANK);
			}
		}
		
	}

	
	/**
	 * Copies a given board to overwrite this board
	 * @param toCopy
	 * The given board
	 */
	public void copyBoard(Board toCopy) {
		this.setIsWon(toCopy.isWon);
		for (int i = 0; i < 6; i++){	
			for (int j = 0; j < 7; j++){
				this.board[i][j].modifyTile(toCopy.board[i][j].getData());
			}
		}
	}
	
	
	/**
	 * Gets the board, which is a 2D array
	 * @return
	 * The board
	 */
	public Tile[][] get2dArray(){
		return this.board;		
	}
	
	
	/**
	 * Gets whether the game has been won yet
	 * @return
	 * PLAYER_ONE_WINS (1) if Player One has won, PLAYER_TWO_WINS (2) if Player Two has won, 
	 * NO_DRAW (0) if nobody has won yet, and DRAW (3) if the game is a draw and the board is full.
	 */
	public int getHasWon() {
		return isWon;
	}
	
	
	/**
	 * Sets the 2D array of this board
	 * @param b
	 * 2D array
	 */
	public void setBoard(Tile[][] b) {
		board = b;
	}
	
	
	/**
	 * Sets whether this board has been won
	 * @param is
	 * PLAYER_ONE_WINS (1) if Player One has won, PLAYER_TWO_WINS (2) if Player Two has won, 
	 * NO_DRAW (0) if nobody has won yet, and DRAW (3) if the game is a draw and the board is full.
	 */
	public void setIsWon(int is) {
		isWon = is;
	}
	
}
