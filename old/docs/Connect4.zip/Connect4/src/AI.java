
/**
 * In a one-player game with the Player versing the AI, the AI will use a minimax strategy to determine its next move.
 * The strategy attempts to minimises the AI's loss for the worst case scenario.
 */

public class AI {
	
	private int lookahead;
	
	protected static final int EASY = 2;
	protected static final int MEDIUM = 4;
	protected static final int HARD = 6;
		
	/**
	 * Class constructor.
	 * @param difficulty
	 * The difficulty setting (easy, medium or hard) determines how far the AI looks ahead in its search.
	 */
	public AI (int difficulty) {
		lookahead = difficulty;
	}
	
	/**
	 * Finds the column for which the AI will play its next move
	 * @param g
	 * The game
	 * @return
	 * The column the AI will place its token in
	 */
	public int getNextMove(Game g) {
		Heuristic bestCol = CompTurn(g.getBoard(), lookahead, 1, 0);
		System.out.println("Best Value: " + bestCol.getValue());
		System.out.println("Best Col " + bestCol.getCol());
		return bestCol.getCol();
	}
	
	/**
	 * Calculates the maximum cost for the AI's turn
	 * @param b
	 * The board
	 * @param maxDepth
	 * The maximum depth to search, depending on AI's difficulty
	 * @param currDepth
	 * The current depth
	 * @param lastCol
	 * The last column
	 * @return
	 */
	Heuristic CompTurn(Board b, int maxDepth, int currDepth, int lastCol) {
		if (currDepth > maxDepth || b.hasWonYellow()){
			if (b.isFree(lastCol)){
				Heuristic game = new Heuristic(b, lastCol, currDepth);
				return game;
			}
		}
		Heuristic max = new Heuristic(b, 0, 0);
		max.setValue(-100000);
		
		for (int i = 0; i < 7 ; i++){
			// Create new Board for all possible moves
			Board copy = new Board();
			copy.copyBoard(b);
			Heuristic y = null;
			if (copy.isFree(i)) {
				copy.addPiece(Game.PLAYER_ONE, i);
				System.out.println("i = " + i);
				y = PlayerTurn(copy, maxDepth, currDepth + 1, i);
			}
			if (y != null){
				if (y.getValue() > max.getValue()){
					max = y;
				}
			}
		}
		System.out.println();
		return max;	
	}
	
	/**
	 * Calculates the minimum cost for the player's turn
	 * @param b
	 * The board
	 * @param maxDepth
	 * The maximum depth to search, depending on AI's difficulty
	 * @param currDepth
	 * The current depth
	 * @param lastCol
	 * The last column
	 * @return
	 */
	Heuristic PlayerTurn(Board b, int maxDepth, int currDepth, int lastCol) {
		if ((currDepth >  maxDepth || b.hasWonRed())){
			if (b.isFree(lastCol)){
			Heuristic game = new Heuristic(b, lastCol, currDepth);
			return game;
			}
		}
		Heuristic min = new Heuristic(b, 0, 0);
		min.setValue(100000);
		for (int j = 0; j < 7 ; j++){
			// Creates Board for all possible Moves
			Board copy = new Board();
			copy.copyBoard(b);
			Heuristic x = null;			
			if (copy.isFree(j)){
				copy.addPiece(Game.PLAYER_TWO, j);
				System.out.println("j = " + j);
				x = CompTurn(copy, maxDepth, currDepth + 1, j);
			}
			if (x != null){
				if (x.getValue() < min.getValue()){
					min = x;
				}
			}
		}
		return min;	
	}


	/**
	 * Returns the difficulty setting of the AI
	 * @return
	 * Easy, medium or hard
	 */
	public String getDiff() {
		if (lookahead == EASY) {
			return "Easy";
		} else if (lookahead == MEDIUM) {
			return "Medium";
		} else {
			return "Hard";
		}
	}
}
