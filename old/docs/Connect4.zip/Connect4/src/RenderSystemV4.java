import java.awt.Color;

import javax.swing.JFrame;

public class RenderSystemV4 extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6019618908287272933L;
	
	private JFrame mainFrame;
	private RenderSystemBoard rsb;
	private GamePanelV4 gp;
	private MenuPanelV4 mp;
	private InfoPanelV4 ip;
	private OptPanelV4 op;
	
	private Color bgColour;
	
	private Game game;
	
	/**
	 * Creates a new Connect4 window with Game g as the game being displayed.
	 * @param g
	 * The game to be played on this Connect4 window.
	 */
	public RenderSystemV4(Game g) {
		bgColour = new Color(103,119,145);
		game = g;
		rsb = new RenderSystemBoard(game.getBoard());
		gp = new GamePanelV4(this, rsb, g);
		mp = new MenuPanelV4(this);
		ip = new InfoPanelV4(g);
		op = new OptPanelV4(this, game);
		
		mainFrame = new JFrame("Connect4");
		mainFrame.setBounds(100,100,1080,700);
		mainFrame.setLayout(null);
		mainFrame.setBackground(bgColour);
		mainFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		mainFrame.add(gp);
		gp.setBounds(0,0,700,600);
		gp.setBackground(bgColour);
		
		mainFrame.add(mp);
		mp.setBounds(0,600,700,100);
		mp.setBackground(bgColour);
		
		mainFrame.add(ip);
		ip.setBounds(700,0,380,600);
		ip.setBackground(bgColour);
	
		
		mainFrame.add(op);
		op.setBounds(700,600,380,100);
		op.setBackground(bgColour);
				
		mainFrame.setVisible(true);	
	}

	/**
	 *  Shows the AI difficulty panel in the options panel.
	 */
	public void showDiffPanel() {
		op.setDiffButtonsVisible(true);
		repaint();
	}
	
	/**
	 *  Shows options for a new game in the options panel.
	 */
	public void showNewGamePanel() {
		op.setGameOptionsVisible(true);
		repaint();
	}
	
	/**
	 * Updates the message in the information panel with a new message.
	 * @param msg
	 * The message to be displayed in the information panel's miscellaneous message box.
	 */
	public void updateMessage(String msg) {
		ip.setMiscMessage(msg);
	}

	/**
	 * Hides the AI difficulty options.
	 */
	public void hideDiffPanel() {
		op.setDiffButtonsVisible(false);		
	}
	
	/**
	 * Hides the new game options
	 */
	public void hideNewGamePanel() {
		op.setGameOptionsVisible(false);
	}

	/**
	 * Resets the board representation in RenderSystemBoard.
	 * NOTE: does not change the board in game!
	 */
	public void resetBoard() {
		rsb.clear();
		gp.repaint();
	}

	/**
	 * Causes the information panel to update itself with the latest information
	 * available from the game.
	 */
	public void refreshGameData() {
		ip.refreshGameData();
	}

	/**
	 * Disables entry lock on the game panel once someone has finished.
	 */
	public void resetGamePanel() {
		gp.setEntryEnabled(true);
	}
}
