import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;


public class GamePanelV4 extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4789915755072625259L;
	RenderSystemBoard rsb;
	RenderSystemV4 rs;
	Game game;
	JPanel thisPanel;
	
	private BufferedImage texEmptySlot;
	private BufferedImage texP1Token;
	private BufferedImage texP2Token;
	private BufferedImage texP1Tentative;
	private BufferedImage texP2Tentative;
	private boolean entryEnabled;
	
	/**
	 * Creates a new GamePanel with the specified parent RenderSystem, associated
	 * RenderSystemBoard to obtain information from, and the game itself (when changes need to be committed).
	 * @param rs
	 * The RenderSystem which is the parent of this panel
	 * @param rsb
	 * The RenderSystemBoard which contains information about what must be rendered.
	 * @param g
	 * The game which is being played.
	 */
	public GamePanelV4(RenderSystemV4 rs, RenderSystemBoard rsb, Game g) {
		this.rsb = rsb;
		this.rs = rs;
		thisPanel = this;
		this.setLayout(null);
		entryEnabled = true;
		
		this.addMouseListener(new MouseAdapter() {
			public void mouseReleased(MouseEvent me) {
				Point p = me.getPoint();
				if (thisPanel.getBounds().contains(p) && ((GamePanelV4) thisPanel).isEntryEnabled()) {
					game.dropToken((int)(p.x / 100));
					((GamePanelV4) thisPanel).updateDisplay();
					((GamePanelV4) thisPanel).refreshGameData();
					thisPanel.repaint();
				}
				System.out.println("released on column " + (int)(p.x / 100));
				
			}
		});
		game = g;
		
		try {
			texEmptySlot = ImageIO.read(new File("res\\empty.jpg"));
			texP1Token = ImageIO.read(new File("res\\player_one.jpg"));
			texP2Token = ImageIO.read(new File("res\\player_two.jpg"));
			texP1Tentative = ImageIO.read(new File("res\\texP1Tentative.jpg"));
			texP2Tentative = ImageIO.read(new File("res\\texP2Tentative.jpg"));
		} catch (IOException e) {
		}
		
		
		repaint();
	}
	
	/**
	 * Causes the information panel to refresh all data associated about the game.
	 * Must go through RenderSystem as the panels are not intended to have
	 * communications with each other.
	 */
	protected void refreshGameData() {
		rs.refreshGameData();
	}

	public void paint(Graphics g) {
		// Repaint each and every one of the 100x100px
		for (int i = 0; i < 7; i++) {
			for (int j = 0; j < 6; j++) {
				int tileType = rsb.getTileType(i,j);
				if (tileType == rsb.EMPTY){
					g.drawImage(texEmptySlot, i*100, j*100, null);
				} else if (tileType == rsb.P1_TOKEN) {
					g.drawImage(texP1Token, i*100, j*100, null);
				} else if (tileType == rsb.P2_TOKEN) {
					g.drawImage(texP2Token, i*100, j*100, null);
				} else if (tileType == rsb.P1_TENTATIVE){
					g.drawImage(texP1Tentative, i*100, j*100, null);
				} else if (tileType == rsb.P2_TENTATIVE) {
					g.drawImage(texP2Tentative, i*100, j*100, null);
				}				
			}
		}
	}
	
	/**
	 *	Updates GamePanel so that it shows the latest version of the board. 
	 */
	public void updateDisplay() {
		// If something has changed in the render system board
		// Update the display.
		// Otherwise, send an error message to the InfoPanel.
		if (rsb.update()) {
			repaint();
			int boardState = game.getHasWon();
			if (boardState == Game.NO_DRAW) {
				rs.updateMessage("Successfully placed token.");
			} else if (boardState == Game.PLAYER_ONE_WINS) {
				rs.updateMessage("Player one has won!");
				setEntryEnabled(false);
			} else if (boardState == Game.PLAYER_TWO_WINS) {
				rs.updateMessage("Player two has won!");
				setEntryEnabled(false);
			} else {
				rs.updateMessage("The game has ended with a draw!");
				setEntryEnabled(false);
			}
		} else {
			rs.updateMessage("Invalid move - column is full.");
		}
	}

	/**
	 * Allows changing of games if necessary.
	 * @param game2
	 */
	public void setGame(Game game2) {
		game = game2;
	}
	
	/**
	 * Checks if this GamePanel is not locked by a victory.
	 * @return
	 * Whether or not this GamePanel is locked.
	 */
	public boolean isEntryEnabled() {
		return entryEnabled;
	}
	
	/**
	 * Sets this GamePanel's input lock state.
	 * @param setting
	 * True disables input from GamePanel
	 * False enables input.
	 */
	public void setEntryEnabled(boolean setting) {
		entryEnabled = setting;
	}
}
