
/**
 * A Game consists of a Board and other information on the current game: the type of game (Player vs AI or Player vs Player),
 * the current player's turn and the total turn count.
 */

public class Game {
	
	private int numPlayers;
	private int currPlayer;
	private int currTurn;
	private int victory;
	
	private static Board board;
	private static AI ai;
	
	final protected static int EASY = 101;
	final protected static int MEDIUM = 102;
	final protected static int HARD = 103;
	
	final protected static int PLAYER_ONE = 1;
	final protected static int PLAYER_TWO = 2;
	protected static final int ONE_PLAYER = 201;
	protected static final int TWO_PLAYER = 202;
	public static final int NO_DRAW = 300;
	public static final int PLAYER_ONE_WINS = 301;
	public static final int PLAYER_TWO_WINS = 302;
	public static final int DRAW = 303;
	
	/**
	 * Creates a default starting game, with 2 human players.
	 * Sets player 1 to be the starting player.
	 * Creates a new blank board.
	 * Initialises a new AI set to easy difficulty.
	 */
	public Game() {
		board = new Board();
		ai = new AI(AI.EASY);
		numPlayers = ONE_PLAYER;
		currPlayer = PLAYER_ONE;
		currTurn = 1;
		victory = NO_DRAW;
	}
		
	
	/**
	 * Drops a token for the current player.
	 * @param column
	 * The column in which to add the token.
	 * @return The row in which the token was added, or -1 if it could not be added.
	 * 
	 */
	public int dropToken(int column) {
		// If this is the second player's turn and this is the AI
		// The AI must override the column to drop the token in.
		if (currPlayer == PLAYER_TWO && numPlayers == ONE_PLAYER) {
			column = ai.getNextMove(this);
		}
		
		// If it works, return the row number that it worked on.
		// Otherwise return -1.
		int pieceAddedTo = board.addPiece(currPlayer, column);
		
		if (pieceAddedTo != -1) {
			if (currPlayer == PLAYER_ONE) {
				currPlayer = PLAYER_TWO;
			} else {
				currPlayer = PLAYER_ONE;
				currTurn++;
			}
		}	
		
		victory = board.getHasWon();
		return pieceAddedTo;
	}

	
	/**
	 * Creates a brand new board,
	 * Resets turn counter
	 * Sets player count to 1P or 2P as required
	 * AI need not be changed.
	 * @param playerCount
	 * One-player or two-player
	 */
	public void newGame(int playerCount) {
		if (playerCount == ONE_PLAYER) {
			currTurn = 0;
			board.clear();
			currPlayer = PLAYER_ONE;
			victory = NO_DRAW;
			numPlayers = ONE_PLAYER;
		} else {
			currTurn = 0;
			board.clear();
			currPlayer = PLAYER_ONE;
			victory = NO_DRAW;
			numPlayers = TWO_PLAYER;
		}
	}
	
	
	/**
	 * Returns the type of game
	 * @return Player versus AI or a second Player
	 * 
	 */
	public String getGameType() {
		if (numPlayers == ONE_PLAYER) {
			return ("Player vs AI");
		} else {
			return ("Player vs Player");
		}
	}
	
	
	/**
	 * Returns the current player
	 * @return Player One or Two
	 * 
	 */
	public String getCurrentPlayer() {
		if (currPlayer == PLAYER_ONE) {
			return "Player One";
		} else {
			return "Player Two";
		}
	}

	
	/**
	 * 
	 * @return Returns the current turn number
	 */
	public int getTurnCount() {
		return currTurn;
	}
	
	
	/**
	 * Returns whether anybody has won the game.
	 * Currently, with NO_DRAW as the return value, this game will always allow inputs.
	 * @return Returns one of four constants: NO_DRAW, DRAW, PLAYER_ONE_WIN, PLAYER_TWO_WIN.
	 * 
	 */
	public int getHasWon() {
		return victory;
	}
	
	
	/**
	 * 
	 * @return Returns the board
	 */
	public Board getBoard() {
		return board;
	}
	
	
	/**
	 * Returns the next empty row in the given column
	 * @param column
	 * @return The row number
	 * 
	 */
	public int getNextAvailableHeight(int column) {
		return board.getNextEmpty(column);
	}

	
	/**
	 * 
	 * @return Returns the current AI difficulty setting
	 */
	public String getDiff() {
		// Make sure that GUI is initialised AFTER difficulty setting is initialised!
		return ai.getDiff();
	}
	
	
	/**
	 * Changes the difficulty setting of the AI
	 * @param diff The new difficulty - easy, medium or hard
	 * 
	 */
	protected void changeDiff (int diff) {
		ai = new AI(diff);
	}
	
}
