
/**
 * Heuristic class that holds the state of the board to be used when the AI calculates all possible states of the board.
 * The Heuristic used is how many adjacent pieces is present for every yellow (computer) piece. 
 * The more tokens there are, the higher the value of the Heuristic.
 */

public class Heuristic {
	
	private int Col;
	private int value;
	private Board board;
		
	/**
	 * Class constructor.
	 * @param board
	 * @param lastCol
	 * @param currDepth
	 */
	public Heuristic (Board board, int lastCol, int currDepth){
		this.board = board;
		this.Col = lastCol;
		this.value = analyze(this.board);
	}
	
	
	/**
	 * Calculates the total heuristic cost
	 * @param g
	 * The current game
	 * @return Heuristic cost
	 * 
	 */
	public static int analyze(Board g) {
		return g.calculateHeuristic(g);
	}
	
	
	/**
	 * Returns a copy of the given game
	 * @param g
	 * @return The given game
	 */
	public static Game copyGame(Game g) {
		Game newGame = new Game();
		return newGame;
	}

	
	/**
	 *
	 * @return Returns the column
	 */
	public int getCol() {
		return this.Col;
	}
	

	/**
	 * 
	 * @return Returns the value
	 */
	public int getValue() {	
		return value;
	}

	
	/**
	 * Sets the best column
	 * @param bestCol
	 */
	public void setCol(int bestCol) {
		this.Col = bestCol;
	}
		
	
	/**
	 * Sets the value
	 * @param value
	 */
	public void setValue(int value) {
		this.value = value;
	}

}
