import java.util.ArrayList;
import java.util.Iterator;

public class RenderSystemBoard{
	
	// NOTE: THIS CLASS IS NOT THE SAME AS THE BOARD REPRESENTATION USED BY THE GAME.
	// THIS IS PURELY USED FOR DISPLAYING THE BOARD.
	
	private class Tile {
		int tileType;
		
		Tile() {
			tileType = EMPTY;
		}
		
		int getTileType() {
			return tileType;
		}
		
		void setTileType(int type) {
			tileType = type;
		}
	}
	
	protected final int EMPTY = 0;
	protected final int P1_TOKEN = 1;
	protected final int P2_TOKEN = 2;
	protected final int P1_TENTATIVE = 3;
	protected final int P2_TENTATIVE = 4;
	
	private Board board;
	
	ArrayList<Tile> tileArray;
	
	/**
	 * Creates a new RenderSystemBoard from the given board b.
	 * This board will be the reference from which all changes will be obtained.
	 * @param b
	 * The board of the current game.
	 */
	public RenderSystemBoard(Board b) {
		tileArray = new ArrayList<Tile>();
		board = b;
		// Tile array is filled up one column at a time, left to right, top to bottom.
		
		for (int i = 0; i < 7; i++) {
			for (int j = 0; j < 6; j++) {
				tileArray.add(new Tile());
			}
		}
	}
	
	/**
	 * Gets the tile type from grid location (x,y).
	 * @param x
	 * The x-coordinate of the tile. 
	 * @param y
	 * The y-coordinate of the tile.
	 * @return
	 * The type of token which exists (or does not exist) on this tile.
	 */
	public int getTileType(int x, int y) {
		return tileArray.get(x + y*7).getTileType();
	}
	
	/**
	 * Changes the tile at (x,y) to the required type.
	 * @param x
	 * The x-coordinate of the tile.
	 * @param y
	 * The y-coordinate of the tile.
	 * @param type
	 * The type of token which needs to exist at this tile.
	 */
	public void changeTileType(int x, int y, int type) {
		tileArray.get(x + y*7).setTileType(type);
	}
	
	/**
	 * Updates this representation of the board so that it is the same
	 * as the representation of the board as seen by the game.
	 * @return
	 * True if something has been changed.
	 * False otherwise.
	 */
	public boolean update() {
		
		boolean success = false;
		
		// For each tileArray object, get the new layout.
		Iterator<Tile> tileIterator = tileArray.iterator();
		Tile current;
		
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; j++) {
				current = tileIterator.next();
				if (current.getTileType() != board.getTileType(i,j)) {
					current.setTileType(board.getTileType(i,j));
					success = true;
				}
			}
		}
		
		return success;
	}

	/**
	 *	Resets the tiles in this board representation. 
	 */
	public void clear() {
		// Resets all tiles.
		Iterator<Tile> tileIterator = tileArray.iterator();
		Tile current;
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; j++) {
				current = tileIterator.next();
				current.setTileType(EMPTY);
			}
		}
	}


}
