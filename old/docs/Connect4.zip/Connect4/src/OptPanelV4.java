import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;


public class OptPanelV4 extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4623114559112711794L;
	JButton diffHard;
	JButton diffMedium;
	JButton diffEasy;
	
	JButton newGameOnePlayer;
	JButton newGameTwoPlayer;
	
	Game game;
	RenderSystemV4 rs;
	OptPanelV4 thisPanel;
	
	/**
	 * Creates a new option panel which is initially invisible.
	 * This contains all the buttons which the user needs to change settings about the game.
	 * @param r
	 * The parent RenderSystem of this panel.
	 * @param g
	 * The game which is modified by this OptionPanel.
	 */
	public OptPanelV4(RenderSystemV4 r, Game g) {
		game = g;
		rs = r;
		thisPanel = this;
		thisPanel.isOptimizedDrawingEnabled();
		thisPanel.setLayout(null);
		
		diffEasy = new JButton("Easy");
		diffEasy.setBounds(0,0,100,50);
		diffEasy.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// Set game difficulty to easy.
				game.changeDiff(AI.EASY);
				rs.refreshGameData();
				thisPanel.setDiffButtonsVisible(false);
			}
			
		});
		
		diffMedium = new JButton("Medium");
		diffMedium.setBounds(105,0,100,50);
		diffMedium.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// Set game difficulty to medium.
				game.changeDiff(AI.MEDIUM);
				rs.refreshGameData();
				thisPanel.setDiffButtonsVisible(false);
			}
			
		});
		
		diffHard = new JButton("Hard");
		diffHard.setBounds(210,0,100,50);
		diffHard.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// Set game difficulty to hard.
				game.changeDiff(AI.HARD);
				rs.refreshGameData();
				setDiffButtonsVisible(false);
			}
		});
		
		newGameOnePlayer = new JButton("One Player");
		newGameOnePlayer.setBounds(0,0,150,50);
		newGameOnePlayer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Creates a new game, with one player.
				game.newGame(Game.ONE_PLAYER);
				rs.resetBoard();
				rs.resetGamePanel();
				setGameOptionsVisible(false);
			}
		});
		
		newGameTwoPlayer = new JButton("Two Players");
		newGameTwoPlayer.setBounds(155,0,150,50);
		newGameTwoPlayer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Creates a new game, with two players.
				game.newGame(Game.TWO_PLAYER);
				rs.resetBoard();
				rs.resetGamePanel();
				setGameOptionsVisible(false);
			}
		});
		
		thisPanel.add(diffEasy);
		thisPanel.add(diffMedium);
		thisPanel.add(diffHard);
		thisPanel.add(newGameOnePlayer);
		thisPanel.add(newGameTwoPlayer);
		
		thisPanel.setDiffButtonsVisible(false);
		thisPanel.setGameOptionsVisible(false);
		thisPanel.setComponentZOrder(diffEasy, 0);
		thisPanel.setComponentZOrder(diffMedium, 1);
		thisPanel.setComponentZOrder(diffHard, 2);
		thisPanel.setComponentZOrder(newGameOnePlayer, 3);
		thisPanel.setComponentZOrder(newGameTwoPlayer, 4);
	}

	/**
	 * Sets the difficulty buttons to be visible or invisible.
	 * @param visibility
	 * True to make the difficulty buttons visible
	 * False otherwise.
	 */
	public void setDiffButtonsVisible(boolean visibility) {
		diffHard.setVisible(visibility);
		diffEasy.setVisible(visibility);
		diffMedium.setVisible(visibility);
	}

	/**
	 * Sets the new game options to be visible or invisible.
	 * @param visibility
	 * True to make the new game options visible
	 * False otherwise.
	 */
	public void setGameOptionsVisible(boolean visibility) {
		newGameOnePlayer.setVisible(visibility);
		newGameTwoPlayer.setVisible(visibility);
	}
}
