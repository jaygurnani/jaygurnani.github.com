
/**
 * A Tile represents one square on a Board.
 * It can be blank, red or yellow.
 */

public class Tile {
	
	private int colour;
	
	/**
	 * Class constructor.
	 * @param type
	 * Colour of the tile
	 */
	public Tile(int type){
		colour = type;
	}
	
	
	/**
	 * 
	 * @return Returns the colour of the tile
	 */
	public int getData(){
		return colour;
	}
	
	
	/**
	 * Changes the colour of the tile
	 * @param type
	 * Colour of the tile
	 */
	public void modifyTile(int type){
		colour = type;
	}

}
