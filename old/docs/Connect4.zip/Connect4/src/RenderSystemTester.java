public class RenderSystemTester{
	public static void main (String[] args) {
		RenderSystemV4 rs = new RenderSystemV4(new Game());
	}
}
