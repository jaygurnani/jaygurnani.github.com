import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
public class MenuPanelV4 extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8067255286008080301L;
	private JButton startButton;
	private JButton exitButton;
	private JButton diffOptButton;
	private RenderSystemV4 rs;
	
	/**
	 * Creates a new Menu Panel which enables users to pick options
	 * with the parent RenderSystem r.
	 * Also creates the action listeners associated with each component as required.
	 * @param r
	 * The parent RenderSystem.
	 */
	public MenuPanelV4 (RenderSystemV4 r) {
		
		rs = r;
		
		this.setLayout(null);
		
		startButton = new JButton("Start new game");
		exitButton = new JButton("Exit");
		diffOptButton = new JButton("Difficulty...");
		
		startButton.addActionListener(new
			ActionListener()
			{
				public void actionPerformed(ActionEvent event)
				{	
					rs.showNewGamePanel();
					rs.hideDiffPanel();
				}
			}
		);
		startButton.setBounds(0,0,100,50);
		startButton.setVisible(true);
		
		exitButton.addActionListener(new
			ActionListener()
		{
			public void actionPerformed(ActionEvent event)
				{
					// Exit the program.
					System.exit(0);
				}
			}
		);
		exitButton.setBounds(100,0,100,50);
		exitButton.setVisible(true);
		
		diffOptButton.addActionListener(new
			ActionListener()
		{
			public void actionPerformed(ActionEvent event)
			{
				// Show the difficulty choosing panel.
				rs.showDiffPanel();
				rs.hideNewGamePanel();
			}
		});
		diffOptButton.setBounds(200,0,100,50);
		diffOptButton.setVisible(true);
		
		this.add(startButton);
		this.add(exitButton);
		this.add(diffOptButton);
		this.setBackground(new Color(103,119,145));
	}
}
